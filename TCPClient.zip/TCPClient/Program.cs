﻿using System;
using System.Net.Sockets;

namespace TCPClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("TCP Client Starting…..");

            while (true)

            {

                var message = Console.ReadLine();

                var bytes = System.Text.Encoding.Unicode.GetBytes(message);



                SendMessage(bytes);

            }

        }



        private static byte[] SendMessage(byte[] messageBytes)

        {

            const int bytesize = 1024 * 1024;

            try

            {

                System.Net.Sockets.TcpClient client = new System.Net.Sockets.TcpClient("127.0.0.1", 3077);

                NetworkStream stream = client.GetStream();

                stream.Write(messageBytes, 0, messageBytes.Length);

                Console.WriteLine("Connected to server.");

                messageBytes = new byte[bytesize];

                // Receive the stream of bytes

                stream.Read(messageBytes, 0, messageBytes.Length);

                var messageToPrint = System.Text.Encoding.Unicode.GetString(messageBytes);

                Console.WriteLine(messageToPrint);

                stream.Dispose();

                client.Close();

            }

            catch (Exception ex)

            {

                Console.WriteLine(ex.Message);

            }
            return messageBytes; // Return response
        }

    }
}