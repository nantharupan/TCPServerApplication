﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using TCPServer.Configuration;
using TCPServer.Model;

namespace TCPServer.Services
{
    public class DevicePlayService : IDevicePlayService
    {
        private readonly IMongoCollection<DeviceLocation> _deviceLocation;
        private readonly TenantConfiguration _appSettings;

        public DevicePlayService(IOptions<TenantConfiguration> appSettings)
        {
          

            MongoClient dbClient = new MongoClient("mongodb+srv://User:User123@cluster0.8hake.mongodb.net/GPSTracking?retryWrites=true&w=majority");

            var dbList = dbClient.ListDatabases().ToList();

        
            var database = dbClient.GetDatabase("GPSTracking");

            _deviceLocation = database.GetCollection<DeviceLocation>(appSettings.Value.CollectionName);

           

        }
        public bool AddDevicePlay(Byte[] devicelocationPacket)
        {
           
            Console.WriteLine("Message Recieved");
            var message = Encoding.Unicode.GetString(devicelocationPacket);
            var device = new DeviceLocation
            {
                OriginalMessage = message
            };
            _deviceLocation.InsertOne(device);
            Console.WriteLine(message);
            return true;
        }
    }
}
