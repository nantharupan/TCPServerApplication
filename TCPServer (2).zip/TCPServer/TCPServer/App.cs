﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using TCPServer.Configuration;
using TCPServer.Services;

namespace TCPServer
{
    public class App
    {
        private readonly ILogger<App> _logger;
        private readonly TenantConfiguration _appSettings;
        private readonly IDevicePlayService _devicePlayService;

        public App(IOptions<TenantConfiguration> appSettings, ILogger<App> logger, IDevicePlayService devicePlayService)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _appSettings = appSettings?.Value ?? throw new ArgumentNullException(nameof(appSettings));
            _devicePlayService = devicePlayService;
        }

        public async Task Run(string[] args)
        {
            _logger.LogInformation("Starting...");

            Console.WriteLine("Hello world!");
            Console.WriteLine(_appSettings.CollectionName);

            _logger.LogInformation("Finished!");

            IPEndPoint ep = new IPEndPoint(IPAddress.Any, 3078);

            TcpListener server = new TcpListener(ep);

            server.Start(); // start the server

            Console.WriteLine($"TCP server in docker started with ip: { ep.Address}, port: { ep.Port}. Waiting for connection…..");

            while (true)

            {
                const int size = 1024 * 1024;

                string message = null;

                byte[] buffer = new byte[size];

                var sender = server.AcceptTcpClient();

                sender.GetStream().Read(buffer, 0, size);

                // Read the message

                _devicePlayService.AddDevicePlay(buffer);

                message = Encoding.Unicode.GetString(buffer);

                Console.WriteLine($"Message received: { message}");


                byte[] bytes = System.Text.Encoding.Unicode.GetBytes("Reply message: " + message);

                sender.GetStream().Write(bytes, 0, bytes.Length); // Send the reply


                

            }


            await Task.CompletedTask;
        }
    }
}
