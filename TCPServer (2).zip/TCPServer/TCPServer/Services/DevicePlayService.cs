﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TCPServer.Configuration;
using TCPServer.Model;

namespace TCPServer.Services
{
    public class DevicePlayService : IDevicePlayService
    {
        private readonly IMongoCollection<DeviceLocation> _deviceLocation;
        private readonly TenantConfiguration _appSettings;

        public DevicePlayService(IOptions<TenantConfiguration> appSettings)
        {
          

            MongoClient dbClient = new MongoClient("mongodb+srv://User:User123@cluster0.8hake.mongodb.net/GPSTracking?retryWrites=true&w=majority");

            var dbList = dbClient.ListDatabases().ToList();

        
            var database = dbClient.GetDatabase("GPSTracking");

            _deviceLocation = database.GetCollection<DeviceLocation>(appSettings.Value.CollectionName);

           

        }
        public bool AddDevicePlay(Byte[] devicelocationPacket)
        {
            try
            {
                Console.WriteLine("Message Recieved");
                //var message = Encoding.Unicode.GetString(devicelocationPacket);
                int messageLength = devicelocationPacket[2];
                string IMEI = Encoding.ASCII.GetString(devicelocationPacket.Skip(4).Take(messageLength - 5).ToArray());
                var year = devicelocationPacket[4];
                var month = devicelocationPacket[5];
                var day = devicelocationPacket[6];
                var hour = devicelocationPacket[7];
                var minute = devicelocationPacket[8];
                var second = devicelocationPacket[9];
                //var date = new DateTime(2000 + year, month, day, hour, minute, second);
                var speed = devicelocationPacket[19];

                var lattitude = new byte[4];
                Array.Copy(devicelocationPacket, 11, lattitude, 0, 4);

                var number = BitConverter.ToUInt32(lattitude.Reverse().ToArray(), 0);
                var lat = (90 * number) / 162000000.0;


                var serialNumber = devicelocationPacket.Skip(2 + 1 + messageLength - 4).Take(2).ToArray();


                var device = new DeviceLocation
                {
                    OriginalPacket = devicelocationPacket,
                    PacketLength = messageLength,
                    SerialNo = serialNumber[0].ToString("X2") + serialNumber[1].ToString("X2"),
                    IEMI = IMEI,
                    GpsTime = DateTime.Now,
                    Speed = speed,
                    Latitude = (decimal)lat
                };
                _deviceLocation.InsertOne(device);
            }
            catch (Exception ex)
            {

                var device = new DeviceLocation
                {
                    OriginalPacket = devicelocationPacket,
                    GpsTime = DateTime.Now
                    
                };
                _deviceLocation.InsertOne(device);
            }
           
           
            //Console.WriteLine(message);
            return true;
        }
    }
}
