﻿using System;
using System.Collections.Generic;
using System.Text;
using TCPServer.Model;

namespace TCPServer.Services
{
    public interface IDevicePlayService
    {
        public bool AddDevicePlay(Byte[] devicelocationPacket);
    }
}
